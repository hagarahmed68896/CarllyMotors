@extends('layouts.app')
@php
    use Illuminate\Support\Facades\Crypt;
    use Illuminate\Support\Str;
@endphp
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<style>
    .btn-outline-danger {
        /* background-color: #760e13 !important; */
        border-color: #760e13 !important;
    }

    .btn-outline-danger:hover {
        background-color: #5a0b0f !important;
        border-color: #5a0b0f !important;
        color: #f3f3f3 !important;
    }

    .carousel-control-prev,
    .carousel-control-next {
        width: 8%;
        padding: 5px;
        background-color: rgba(0, 0, 0, 0.5) !important;

    }

    .carousel-control-prev-icon,
    .carousel-control-next-icon {
        background-color: rgba(0, 0, 0, 0.5) !important;
        padding: 5px;
        width: 8%;
        border-radius: 50%;
        /* color: rgba(0, 0, 0, 0.5) !important; */
    }

    /* تخصيص النقاط */
    .carousel-indicators [data-bs-target] {
        background-color: #fff;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        margin-bottom: 4px;
    }
</style>
@section('content')

    <style>
        .custom-container {
            width: 100%;
            /* افتراضيًا يكون container-fluid */

        }

        /* عند تجاوز 1400px، يصبح مثل container */
        @media (min-width: 1400px) {
            .custom-container {
                max-width: 1250px;
                /* أو أي عرض مناسب */
                margin: 0 auto;
                /* يضمن أن يكون في المنتصف */
            }


        }

        .carousel-item img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100vw;

            min-width: 100vw;
            /* min-height: 100vh;  */
            object-fit: contain;

        }

        .carousel-inner {
            height: 80vh;
            background-color: #5a0b0f !important;
        }

        .carousel {
            position: relative;
        }

        @media (max-width: 470px) {
            .carousel-inner {
                height: 18vh;
                background-color: #5a0b0f !important;
            }
        }

        @media (min-width: 1600px) {
            .carousel {
                max-width: 1250px;
                margin: 0 auto;
                width: 100vw;
                /* height: 30vh; */
            }

            .carousel-inner {
                height: 70vh;
                background-color: #5a0b0f !important;
                object-fit: contain;
                width: 100%;
            }

            .carousel-item img {

                width: 100vw;
                /* min-height: 100vh;  */
                object-fit: contain;

            }
        }

        .filter-bar .form-row>div {
            margin-right: 0.75rem;
            /* مسافة بين العناصر */
        }

        .filter-bar .form-row>div:last-child {
            margin-right: 0;
            /* إزالة المسافة من العنصر الأخير */
        }
    </style>

    <div id="demo" class=" carousel slide mt-1" data-bs-ride="carousel" data-bs-interval="2000">
        <!--  النقاط -->
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
            <button type="button" data-bs-target="#demo" data-bs-slide-to="3"></button>
        </div>

        <!-- الصور -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="d-block   " src="{{asset('1.jpg')}}" alt="Los Angeles">
            </div>
            <div class="carousel-item">
                <img class="d-block   " src="{{asset('2.jpg')}}" alt="Chicago">
            </div>
            <div class="carousel-item">
                <img class="d-block   " src="{{asset('3.jpg')}}" alt="Chicago">
            </div>
            <div class="carousel-item">
                <img class="d-block   " src="{{asset('4.jpg')}}" alt="New York">
            </div>
        </div>

        <!-- أزرار التنقل -->
        <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>

    <!-- Start filter home with items

        -->
    <div class=" my-6 main-home-filter-sec text-center">

        <div class="d-flex flex-wrap justify-content-center gap-3 animate__animated animate__fadeInUp">
            <a href="{{route('cars.index')}}" class="nav-btn active text-decoration-none">
                Cars
            </a>
            <a href="{{route('spareParts.index')}}" class="nav-btn text-decoration-none">
                Spare Parts
            </a>
            <a href="{{route('workshops.index')}}" class="nav-btn text-decoration-none">
                Workshops
            </a>
        </div>
        <!-- الفلتر العادي - يظهر فقط على الشاشات الكبيرة

        -->
        <div class="custom-container main-car-list-sec filter-bar my-2 mx-auto d-none d-md-block">
            <form class="form-row mb-0 text-center" id="filterForm" action="{{route('cars.index')}}" method="get">
                <!-- car_type -->
                <div class="col-">
                    <select class="form-control" onchange="submitFilterForm()" name="car_type"
                        data-placeholder="Select Car Type">
                        <option value="UsedOrNew" {{request('car_type') == 'UsedOrNew' ? 'selected' : ''}}>Used/New</option>
                        <option value="Imported" {{request('car_type') == 'Imported' ? 'selected' : ''}}>Imported</option>
                        <option value="Auction" {{request('car_type') == 'Auction' ? 'selected' : ''}}>Auction</option>
                    </select>
                </div>

                <!-- city -->
                <div class="col-">
                    <select class="form-control" id="city" name="city" data-placeholder="Select City">
                        <option value="" selected>City</option>
                        @foreach($cities as $city)

                            <option value="{{ $city }}" {{ request('city') == $city ? 'selected' : '' }}>{{ $city }}</option>
                        @endforeach
                    </select>
                </div>

                <!-- make -->
                <div class="col-">
                    <select class="form-control" id="brand" name="make" onchange="submitFilterForm()"
                        data-placeholder="Select Make">
                        <option value="">Make</option>
                        @foreach($makes as $make)
                            <option value="{{ $make }}" {{ request('make') == $make ? 'selected' : '' }}>{{ $make }}</option>
                        @endforeach
                    </select>
                </div>

                <!-- model -->
                <div class="col">
                    <select class="form-control" id="model" name="model" onchange="submitFilterForm()"
                        data-placeholder="Select Model">
                        <option value="">Model</option>
                        @foreach($models as $model)
                            <option value="{{ $model }}" {{ request('model') == $model ? 'selected' : '' }}>{{ $model }}</option>
                        @endforeach
                    </select>
                </div>

                <!-- year -->
                <div class="col">
                    <select class="form-control" id="year" name="year" onchange="submitFilterForm()"
                        data-placeholder="Select Year">
                        <option value="">Year</option>
                        @foreach($years as $year)
                            <option value="{{ $year }}" {{ request('year') == $year ? 'selected' : '' }}>{{ $year }}</option>
                        @endforeach
                    </select>
                </div>



                <!-- body_type -->
                <div class="col-">
                    <select class="form-control" onchange="submitFilterForm()" name="body_type"
                        data-placeholder="Select Body Type">
                        <option value="" selected>Body Type</option>
                        @foreach($bodyTypes as $bodyType)
                            <option value="{{ $bodyType }}" {{ request('body_type') == $bodyType ? 'selected' : '' }}>
                                {{ $bodyType }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <!-- regionalSpecs -->
                <div class="col-">
                    <select class="form-control" onchange="submitFilterForm()" name="regionalSpecs"
                        data-placeholder="Select Regional Specs">
                        <option value="" selected>regionalSpecs</option>
                        @foreach($regionalSpecs as $regionalSpec)
                            <option value="{{ $regionalSpec }}" {{ request('regionalSpec') == $regionalSpec ? 'selected' : '' }}>
                                {{ $regionalSpec }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <!-- price -->
                <div class="col-">
                    <button type="button" class="btn button-like-select w-100" onclick="openModal()">Price</button>
                    <div id="priceModal" class="modal">
                        <span class="close" onclick="closeModal()">&times;</span>
                        <h2 style="color:#7b4b40; font-weight:bold; font-size: 20px;">Price</h2>
                        <div class="price-range">
                            <input type="number" id="minPrice" name="priceFrom" min="{{$minPrice}}" max="{{$maxPrice}}"
                                value="{{$minPrice}}">
                            <span>to</span>
                            <input type="number" id="maxPrice" name="priceTo" min="{{$minPrice}}" max="{{$maxPrice}}"
                                value="{{$maxPrice}}">
                        </div>
                        <button class="filter-btn" onclick="submitFilterForm()">Filter</button>
                    </div>
                </div>
            </form>
        </div>



        <div class="custom-container filter-bar-mobile my-3 d-md-none">
            <form id="filterFormMobile" action="{{ route('cars.index') }}" method="get"
                class="d-flex flex-nowrap overflow-auto gap-3 px-2 py-2"
                style="scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch;">

                <!-- car_type -->
                <div class="filter-item px-2" style="min-width: 160px; scroll-snap-align: start;">
                    <select class="form-control" name="car_type" onchange="submitFilterForm()">
                        <option value="UsedOrNew" {{ request('car_type') == 'UsedOrNew' ? 'selected' : '' }}>Used/New</option>
                        <option value="Imported" {{ request('car_type') == 'Imported' ? 'selected' : '' }}>Imported</option>
                        <option value="Auction" {{ request('car_type') == 'Auction' ? 'selected' : '' }}>Auction</option>
                    </select>
                </div>

                <!-- city -->
                <div class="filter-item px-2" style="min-width: 140px; scroll-snap-align: start;">
                    <select class="form-control" name="city">
                        <option value="">City</option>
                        @foreach($cities as $city)
                            @if(!$city) @continue @endif
                            <option value="{{ $city }}" {{ request('city') == $city ? 'selected' : '' }}>{{ $city }}</option>
                        @endforeach
                    </select>
                </div>

                <!-- make -->
                <div class="filter-item px-2" style="min-width: 140px; scroll-snap-align: start;">
                    <select class="form-control" name="make" id="brand" onchange="submitFilterForm()" data-placeholder="Select Make">
                        <option value="">Make</option>
                        @foreach($makes as $make)
                            <option value="{{ $make }}" {{ request('make') == $make ? 'selected' : '' }}>{{ $make }}</option>
                        @endforeach
                    </select>
                </div>

                <!-- model -->
                <div class="filter-item px-2" style="min-width: 140px; scroll-snap-align: start;">
                    <select class="form-control" name="model" id="model" onchange="submitFilterForm()">
                        <option value="">Model</option>
                    </select>
                </div>

                <!-- year -->
                <div class="filter-item px-2" style="min-width: 160px; scroll-snap-align: start;">
                    <select class="form-control" name="year" onchange="submitFilterForm()">
                        <option value="">Year</option>
                        @foreach($years as $year)
                            <option value="{{ $year }}" {{ request('year') == $year ? 'selected' : '' }}>{{ $year }}</option>
                        @endforeach
                    </select>
                </div>
                <!-- body_type -->
                <div class="filter-item px-2" style="min-width: 140px; scroll-snap-align: start;">
                    <select class="form-control" name="body_type" onchange="submitFilterForm()">
                        <option value="">Body Type</option>
                        @foreach($bodyTypes as $bodyType)
                            <option value="{{ $bodyType }}" {{ request('body_type') == $bodyType ? 'selected' : '' }}>
                                {{ $bodyType }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <!-- regionalSpecs -->
                <div class="filter-item px-2" style="min-width: 160px; scroll-snap-align: start;">
                    <select class="form-control" name="regionalSpecs" onchange="submitFilterForm()">
                        <option value="">Regional Specs</option>
                        @foreach($regionalSpecs as $regionalSpec)
                            <option value="{{ $regionalSpec }}" {{ request('regionalSpec') == $regionalSpec ? 'selected' : '' }}>
                                {{ $regionalSpec }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <!-- Price -->
                <div class="filter-item px-2" style="min-width: 100px; scroll-snap-align: start;">
                    <button type="button" class="btn btn-outline-secondary w-100" onclick="openModal()">Price</button>
                </div>

            </form>
        </div>
        <!-- List -->

        <div class="tab-content" id="bodyTypeTabsContent">
            <div class="custom-container main-car-list-sec">
                <div class="row">
                    @foreach ($carlisting as $key => $car)

                        <div class="col-sm-3 col-sm-12 col-md-6 col-lg-4 col-xl-3">
                            <div class="car-card border-0 shadow" style="border-radius: 12px; overflow: hidden;">
                                <!-- Car Image Section with Consistent Aspect Ratio -->
                                <!-- Car Image Section with Consistent Aspect Ratio -->
                                <div class="car-image position-relative" style="
                                    width: 100%;
                                    height: 220px;
                                    background-color: #f0f0f0;
                                    overflow: hidden;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                ">
                                    @if($car->image != null)
                                        <a href="{{ route('car.detail', $car->id) }}"
                                            style="width: 100%; height: 100%; display: block;">
                                            <img id="cardImage" src="{{ env("CLOUDFLARE_R2_URL") . $car->image->image}}"
                                                alt="Car Image" style="
                                                                        height: 100% !important;
                                                                        width: 100% !important;
                                                                        object-fit: cover;
                                                                        object-position: center;
                                                                        transition: transform 0.3s ease-in-out;
                                                                        aspect-ratio: 16/9;
                                                                        cursor: pointer;
                                                                    " loading="lazy"
                                                onerror="this.onerror=null; this.src='{{ asset('carNotFound.jpg') }}">
                                        </a>
                                    @else
                                        <a href="{{ route('car.detail', $car->id) }}"
                                            style="width: 100%; height: 100%; display: block;">
                                            <img id="cardImage" src="{{ asset('carNotFound.jpg') }}" alt="Car Image" style="
                                                                        height: 100% !important;
                                                                        width: 100% !important;
                                                                        object-fit: cover;
                                                                        object-position: center;
                                                                        transition: transform 0.3s ease-in-out;
                                                                        aspect-ratio: 16/9;
                                                                        cursor: pointer;
                                                                    " loading="lazy"
                                                onerror="this.onerror=null; this.src='{{ asset('carNotFound.jpg') }}">
                                        </a>
                                    @endif

                                    <div style="
                                        position: absolute;
                                        top: 10px;
                                        right: 10px;
                                        display: flex;
                                        gap: 8px;
                                        z-index: 10;
                                    ">
                                        <!-- زر المفضلة -->
                                        <div class="icon-group">
                                            @if(auth()->check())
                                                @php
                                                    $favCars = auth()->user()->favCars()->pluck('id')->toArray();
                                                @endphp
                                                <form action="{{ route('cars.addTofav', $car->id) }}" method="post">
                                                    @csrf
                                                    <button title="Add to fav" class="btn btn-sm" type="submit">
                                                        <i class="fas fa-heart fs-4"
                                                            style="color: {{ in_array($car->id, $favCars) ? '#760e13' : 'green' }}"></i>
                                                    </button>
                                                </form>
                                            @else
                                                <a href="{{ route('login') }}" title="Login to add to fav" class="btn btn-sm">
                                                    <i class="fas fa-heart fs-2" style="color: green"></i>
                                                </a>
                                            @endif
                                        </div>


                                        <!-- زر المشاركة -->
                                        <!--  -->
                                        <a href=" https://wa.me/?text={{ urlencode('Hello, i recommend you to check this car ' . route('car.detail', $car->id)) }}"
                                            target="_blank">
                                            <button class="btn btn-outline-danger" style="border-radius: 15px;">
                                                <i class="fa fa-share"></i>

                                            </button>
                                        </a>

                                        <div class="" style="
                                            background: #760e13;
                                            border: none;
                                            color: #fff;
                                            border-radius: 40%;
                                            padding: 5px;
                                            margin-bottom: 3px;
                                            /* box-shadow: 0 2px 6px rgba(0,0,0,0.1); */
                                            cursor: pointer;
                                        ">{{ $car->listing_year }}</div>
                                    </div>

                                    <!-- السنة -->
                                </div>


                                <!-- Car Content Section -->
                                <div class="car-card-body">

                                    <div class="price-location">
                                        <span class="price ">AED {{$car->listing_price}}</span>
                                        @if($car->user?->lat && $car->user?->lng)
                                            <a href="https://www.google.com/maps?q={{$car->user->lat}},{{$car->user->lng}}">
                                                <span class="location"><i class="fas fa-map-marker-alt"></i> {{$car->city}}</span>
                                            </a>
                                        @endif
                                    </div>
                                    <h4 class="showroom-name" style="text-align: start !important;">{{$car->user?->fname}}
                                        {{$car->user?->lname}}
                                    </h4>


                                    <!-- <div class="car-details">
                                                                <p><strong>Make:</strong> <span>{{$car->listing_type}}</span></p>
                                                                <p><strong>Model:</strong> <span>{{$car->listing_model}}</span></p>
                                                                <p><strong>Year:</strong> <span>{{$car->listing_year}}</span></p>
                                                                <p><strong>Mileage:</strong> <span>215000 Kms</span></p>
                                                            </div> -->

                                    <!-- <div class="car-details" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px 20px;">
                                    <div>
                                        <p><strong>Make:</strong> <span>{{$car->listing_type}}</span></p>
                                    </div>
                                    <div>
                                        <p><strong>Year:</strong> <span>{{$car->listing_year}}</span></p>
                                    </div>
                                    <div>
                                        <p><strong>Model:</strong> <span>{{$car->listing_model}}</span></p>
                                    </div>
                                    <div>
                                        <p><strong>Mileage:</strong> <span>21..Kms</span></p>
                                    </div>

                                </div> -->

                                    <div class="car-details container">
                                        <div class="row mb-2">
                                            <div class="col-6">
                                                <p><strong>Make:</strong> <span>{{$car->listing_type}}</span></p>
                                            </div>
                                            <div class="col-6">
                                                <p><strong>Year:</strong> <span>{{$car->listing_year}}</span></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <p><strong>Model:</strong>
                                                    <span>{{ substr(trim($car->listing_model), 0, 6) }}</span>
                                                </p>
                                            </div>
                                            <div class="col-6">
                                                <p><strong>Mileage:</strong> <span>{{ substr(trim('215Kms'), 0, 6) }}</span></p>
                                                <!-- <p><strong>Mileage:</strong> <span>{{ substr(trim($car->listing_mileage), 0, 6) }}</span></p> -->

                                            </div>
                                        </div>

                                    </div>





                                    <div class="actions">
                                        <a href="https://wa.me/{{ $car->user?->phone }}" target="_blank">
                                            <button class="btn btn-outline-danger" style="border-radius: 25px;">
                                                <i class="fab fa-whatsapp " style="color: #198754; "></i> WhatsApp
                                            </button>
                                        </a>
                                        @if($os == 'Windows' || $os == 'Linux')
                                            <a href="https://wa.me/{{ $car->user?->phone }}" target="_blank">
                                                <button class="btn btn-outline-danger w-100" style="border-radius: 25px; ">
                                                    <i class="fa fa-phone"></i> Call
                                                </button>
                                            </a>
                                        @elseif($os == 'Mac')
                                            <a href={{ 'https://faceapp.com?phone=' . urlencode($car->user?->phone) }}>
                                                <button class="btn btn-outline-danger" style="border-radius: 15px;">
                                                    <i class="fa fa-phone"></i> Call
                                                </button>
                                            </a>
                                        @elseif($os == 'Android' || $os == 'iOS')
                                            <a href="tel:{{ $car->user->phone }}">
                                                <button class="btn btn-outline-danger" style="border-radius: 15px;">
                                                    <i class="fa fa-phone"></i> Make Call
                                                </button>
                                            </a>
                                        @else
                                            No OS Detected
                                        @endif


                                    </div>
                                </div>
                            </div>

                        </div>


                    @endforeach
                </div>
                <div class="mb-0 d-flex justify-content-center" style="margin: 0; float:right">
                    <a href="{{route('cars.index')}}" class="btn btn-outline-danger" style="border-radius: 25px;">
                        View More
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Dealers Section -->
    <div class="my-6 main-home-filter-sec text-center">
        <h2 class="section-title mb-4">Featured Dealers</h2>
        <div class="custom-container main-car-list-sec">
            <div class="row g-4">
                @foreach ($dealers as $key => $dealer)
                    @php
                        $image = Str::after($dealer->company_img, url('/') . '/');
                        $dealerName = ucfirst(strtolower($dealer->company_name));
                        $dealerName = substr($dealerName, 0, 25);
                        $phone = $dealer->user->phone;
                        $shareUrl = request()->path() == 'home'
                            ? request()->url() . '?dealer_id=' . $dealer->id
                            : request()->fullUrl() . '&dealer_id=' . $dealer->id;
                    @endphp

                    <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3 mb-3">
                        <div class="card border-0 shadow-sm h-100" style="border-radius: 16px; overflow: hidden;">
                            <!-- Image -->
                            <div class="position-relative bg-light" style="height: 220px; overflow: hidden;">
                                <img src="{{ config('app.file_base_url') . $image }}" alt="Dealer Image"
                                    class="w-100 h-100 object-fit-cover"
                                    onerror="this.onerror=null; this.src='https://via.placeholder.com/350x219?text=No+Image';"
                                    loading="lazy" />
                            </div>

                            <!-- Content -->
                            <div class="card-body d-flex flex-column justify-content-between">
                                <div class="d-flex flex-row flex-wrap justify-content-between mx-2 mb-3">
                                    <h6 class="fw-bold text-truncate" style="color: #760e13;"
                                        title="{{ $dealer->company_name }}">
                                        {{ $dealerName }}{{ strlen($dealer->company_name) >= 25 ? '...' : '' }}
                                    </h6>
                                    <a href="https://www.google.com/maps/search/?api=1&query={{ urlencode($dealer->company_address) }}"
                                        class="text-muted small d-flex align-items-center text-decoration-none">
                                        <i class="fas fa-map-marker-alt me-1 text-danger">{{ $dealer->user->city }}</i> Location
                                    </a>
                                </div>

                                <!-- Actions -->
                                <div class="d-flex flex-nowrap gap-2 mt-2 justify-content-between mb-2">
                                    <!-- WhatsApp -->
                                    <a href="https://wa.me/{{ $phone }}" target="_blank" class="flex-grow-1">
                                        <button class="btn btn-outline-danger w-100" style="border-radius: 15px;">
                                            <i class="fab fa-whatsapp" style="color: #198754;"></i> WhatsApp
                                        </button>
                                    </a>

                                    <!-- Call -->
                                    @if ($os == 'Windows' || $os == 'Linux')
                                        <a href="https://wa.me/{{ $phone }}" target="_blank" class="flex-grow-1">
                                            <button class="btn btn-outline-danger w-100" style="border-radius: 15px;">
                                                <i class="fa fa-phone"></i> Call
                                            </button>
                                        </a>
                                    @elseif ($os == 'Mac')
                                        <a href="https://faceapp.com?phone={{ urlencode($phone) }}" class="flex-grow-1">
                                            <button class="btn btn-outline-danger w-100" style="border-radius: 15px;">
                                                <i class="fa fa-phone"></i> Call
                                            </button>
                                        </a>
                                    @elseif ($os == 'Android' || $os == 'iOS')
                                        <a href="tel:{{ $phone }}" class="flex-grow-1">
                                            <button class="btn btn-outline-danger w-100" style="border-radius: 15px;">
                                                <i class="fa fa-phone"></i> Call
                                            </button>
                                        </a>
                                    @else
                                        <span class="text-danger flex-grow-1">No OS Detected</span>
                                    @endif

                                    <!-- Share -->
                                    <a href="https://wa.me/?text={{ urlencode('Hello, I recommend you to check this Store ' . $shareUrl) }}"
                                        target="_blank" class="flex-grow-1">
                                        <button class="btn btn-outline-danger w-100" style="border-radius: 15px;">
                                            <i class="fa fa-share"></i> Share
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="mb-0 d-flex justify-content-center" style="margin: 0; float:right">
                <a href="{{route('spareParts.index')}}" class="btn btn-outline-danger" style="border-radius: 25px;">
                    View More Dealers
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- Workshops Section -->
    <div class="my-6 main-home-filter-sec text-center">
        <h2 class="section-title mb-4">Featured Workshops</h2>
        <div class="custom-container main-car-list-sec">
            <div class="row">
                @foreach ($workshops as $workshop)
                    @php
                        $shareUrl = request()->path() == 'home'
                            ? request()->url() . '?workshop_id=' . $workshop->id
                            : request()->fullUrl() . '&workshop_id=' . $workshop->id;
                    @endphp
                    <div class="col-sm-3 col-sm-12 col-md-6 col-lg-4 col-xl-3 mb-3">
                        <div class="car-card border-0 shadow d-flex flex-column h-100" style="border-radius: 12px; overflow: hidden;">

                            <div class="car-image position-relative" style="
                                width: 100%;
                                height: 220px;
                                background-color: #f0f0f0;
                                border-radius: 10px;
                                overflow: hidden;
                                display: flex;
                                align-items: center;
                                justify-content: center;
                            ">
                                @php
                                    $image = $workshop->workshop_logo ? env('CLOUDFLARE_R2_URL') . $workshop->workshop_logo : asset('workshopNotFound.png');
                                @endphp
                                <img id="cardImage" src="{{ config('app.file_base_url') . $image }}" alt="Workshop Image" style="
                                    height: 100% !important;
                                    width: 100% !important;
                                    object-fit: cover;
                                    object-position: center;
                                    transition: transform 0.3s ease-in-out;
                                    aspect-ratio: 16/9;" loading="lazy"
                                    onerror="this.onerror=null; this.src='{{ $image }}'">
                            </div>

                            <div class="card-body d-flex flex-column justify-content-between text-start mx-4 mt-2">
                                <div>
                                    <h5 class="card-title text-truncate" title="{{ $workshop->workshop_name }}"
                                        style="color: #760e13; font-weight: bold">
                                        {{ Str::limit(ucwords(strtolower($workshop->workshop_name)), 25, '...') }}
                                    </h5>

                                    <p class="card-text text-muted mb-1 text-truncate" title="{{ $workshop->address }}"
                                        style="max-width: 100%; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;">
                                        <i class="fas fa-map-marker-alt" style="color:#760e13;"></i>
                                        {{ $workshop->address }}
                                    </p>

                                    <br>

                                    <p class="card-text text-muted">
                                        {{-- Working Hours --}}
                                        @if($workshop->days && $workshop->days->count() > 0)
                                            {{-- اليوم الأول --}}
                                            @if(isset($workshop->days[0]))
                                                <i class="fas fa-clock" style="color:black;"></i>
                                                {{ $workshop->days[0]->day }}: {{ $workshop->days[0]->from }} - {{ $workshop->days[0]->to }}
                                            @endif

                                            {{-- Dropdown لبقي الأيام --}}
                                            @if(count($workshop->days) > 1)
                                                <div class="dropdown mt-2">
                                                    <a class="btn btn-sm btn-outline-secondary dropdown-toggle" href="#" role="button"
                                                        id="dropdownDays{{ $workshop->id }}" data-bs-toggle="dropdown" aria-expanded="false"
                                                        style="border-radius: 10px;">
                                                        more...
                                                    </a>

                                                    <ul class="dropdown-menu" aria-labelledby="dropdownDays{{ $workshop->id }}">
                                                        @foreach($workshop->days as $key => $day)
                                                            @if($key == 0) @continue @endif
                                                            <li class="px-3 py-1 text-muted">
                                                                <i class="fas fa-clock" style="color:#760e13;"></i>
                                                                {{ $day->day }}: {{ $day->from }} - {{ $day->to }}
                                                            </li>
                                                        @endforeach
                                                    </ul>
                                                </div>
                                            @endif
                                        @else
                                            {{-- Fallback when no working hours are available --}}
                                            <i class="fas fa-clock" style="color:#760e13;"></i>
                                            <span class="text-muted">Working hours not available</span>
                                        @endif
                                    </p>

                                    <br>
                                </div>

                                <div class="actions mt-auto">
                                    <a href="https://wa.me/{{ $workshop->user->phone }}" target="_blank">
                                        <button class="btn btn-outline-danger w-100 mb-2" style="border-radius: 15px;">
                                            <i class="fab fa-whatsapp" style="color: #198754;"></i> WhatsApp
                                        </button>
                                    </a>

                                    <a href="tel:{{ $workshop->user->phone }}">
                                        <button class="btn btn-outline-danger w-100 mb-2"
                                            style="border-radius: 15px; margin-left:1px; margin-right:1px">
                                            <i class="fa fa-phone"></i> Call
                                        </button>
                                    </a>

                                    <a href="https://wa.me/?text={{ urlencode('Hello, I recommend you to check this Store ' . $shareUrl) }}"
                                        target="_blank" class="flex-grow-1">
                                        <button class="btn btn-outline-danger w-100" style="border-radius: 15px;">
                                            <i class="fa fa-share"></i> Share
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="mb-0 d-flex justify-content-center" style="margin: 0; float:right">
                <a href="{{route('workshops.index')}}" class="btn btn-outline-danger" style="border-radius: 25px;">
                    View More Workshops
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                </a>
            </div>
        </div>
    </div>

    <div class="container text-center py-5">
        <h2 class="section-title">Search for your favorite car or sell your car on AutoDecar</h2>
        <div class="row">
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="look p-4 text-center">
                    <i class="fas fa-search fa-2x"></i>
                    <h5 class="font-weight-bold">Are you looking for a car?</h5>
                    <p>Save time and effort as you no longer need to visit multiple stores to find the right car.</p>
                    <a href="{{route('cars.index')}}">
                        <button class="btn btn-orange">Find cars</button>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 mb-4 d-flex align-items-center justify-content-center">
                <img class="img-fluid car w-100 " style="    transition: all 0.3s ease-in-out;"
                    src="https://www.car-mart.com/wp-content/uploads/2024/06/red-chevy-sedan.png" alt="">
            </div>
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="look p-4 text-center">
                    <i class="fas fa-search fa-2x"></i>
                    <h5 class="font-weight-bold">Do you want to sell a car?</h5>
                    <p>Find your perfect car match and sell your car quickly with our user-friendly online service.</p>
                    <button class="btn btn-orange">Sell a car</button>
                </div>
            </div>
        </div>
    </div>

    <!-- <div class="container py-5">
            <h2 class="mb-4">Popular Brands</h2>
            <div class="row">
                @foreach ($brands as $brand)
                @if($brand->name == 'Honda' || $brand->name == 'Dodge' ||$brand->name == 'Mazda')
                @continue
                @endif
                <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-4">
                    <div class="brand-card text-center">
                        {{--<img class="img-fluid" src="{{ $brand->logo_url }}" alt="{{ $brand->name }}">--}}
                        <p class="brand-title">{{ $brand->name }}</p>
                        <p class="brand-subtitle">{{ $brand->cars_count ?? 'N/A' }} Cars</p>
                    </div>
                </div>
                @endforeach
            </div>

        </div> -->
    <div class="container py-5">
        <h2 class="mb-4">Popular Brands</h2>
        <div class="row">
            @foreach ($brands->reject(fn($brand) => in_array($brand->name, ['Honda', 'Dodge', 'Mazda']))->take(12) as $brand)
                <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-4">
                    <div class="brand-card text-center">
                        {{--<img class="img-fluid" src="{{ $brand->logo_url }}" alt="{{ $brand->name }}">--}}
                        <p class="brand-title">{{ $brand->name }}</p>
                        <p class="brand-subtitle">{{ $brand->cars_count ?? 'N/A' }} Cars</p>
                    </div>
                </div>
            @endforeach
        </div>
    </div>


    <div class="container py-5 last-home-sec">
        <div class="row justify-content-center">
            <!-- Providers App Section -->
            <div class="col-lg-6 col-md-12 mb-4">
                <div
                    class="custom-card dark-card d-flex flex-column flex-md-row align-items-center text-center text-md-start">
                    <div class="icon-wrapper">
                        <i class="fas fa-user-cog"></i>
                    </div>
                    <div class="px-3">
                        <h5 class="fw-bold">Providers App</h5>
                        <p class="text-muted">Connect with customers and manage your services efficiently.</p>
                        <div class="d-flex flex-column flex-sm-row gap-2 justify-content-center justify-content-md-start">
                            <a href="https://apps.apple.com/us/app/carlly-provider/id6478307755"
                                style="margin-left:12px; margin-right:15px;">
                                <img class="img-fluid store-badge"
                                    src="https://developer.apple.com/assets/elements/badges/download-on-the-app-store.svg"
                                    alt="App Store">
                            </a>
                            <a href="https://play.google.com/store/apps/details?id=com.carllymotors.carllyprovider">
                                <img class="img-fluid store-badge"
                                    src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg"
                                    alt="Google Play">
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Customers App Section -->
            <div class="col-lg-6 col-md-12 mb-4">
                <div
                    class="custom-card dark-card d-flex flex-column flex-md-row align-items-center text-center text-md-start">
                    <div class="icon-wrapper">
                        <i class="fas fa-car"></i>
                    </div>
                    <div class="px-3">
                        <h5 class="fw-bold">Customers App</h5>
                        <p class="text-muted">Access car buying, selling, and maintenance services effortlessly.</p>
                        <div class="d-flex flex-column flex-sm-row gap-2 justify-content-center justify-content-md-start">
                            <a href="https://apps.apple.com/us/app/carlly-motors/id6478306259" class="text-center"
                                style="margin-left:12px; margin-right:15px;">
                                <img class="img-fluid store-badge"
                                    src="https://developer.apple.com/assets/elements/badges/download-on-the-app-store.svg"
                                    alt="App Store">
                            </a>
                            <a href="https://play.google.com/store/apps/details?id=com.carllymotors.carllyuser">
                                <img class="img-fluid store-badge"
                                    src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg"
                                    alt="Google Play">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <style>
        /* تحسين تصميم الكارد */
        .custom-card {
            /* background: linear-gradient(to right, #5a0b0f, #760e13 ); */
            color: white;
            padding: 20px;
            border-radius: 10px;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 15px;
        }

        /* تأثير التحويم */
        .custom-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }

        /* أيقونات */
        .icon-wrapper {
            background: rgba(255, 255, 255, 0.2);
            padding: 15px;
            border-radius: 50%;
            font-size: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 60px;
            height: 60px;
        }

        /* الأزرار */
        .store-badge {
            width: 150px;
            transition: transform 0.2s ease-in-out;
        }

        .car {
            transition: transform 0.2s ease-in-out;
        }

        .car:hover {
            transform: scale(1.1);
        }

        .store-badge:hover {
            transform: scale(1.1);
        }


        .text-muted {
            color: rgba(255, 255, 255, 0.8) !important;
        }
    </style>
    <style>
        /* تحديد ارتفاع موحد لكل select و select2 */
        select.form-control,
        .select2-container .select2-selection--single {
            height: 38px !important;
            /* نفس ارتفاع Bootstrap الافتراضي */
            padding: 6px 12px;
            font-size: 14px;
        }

        /* توسيط النص عموديًا داخل select2 */
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 24px;
            padding-left: 8px;
        }

        .select2-container--default .select2-selection--single {
            border: 1px solid #ced4da;
            border-radius: 4px;
        }

        /* تأكد من أن الـ select2 نفسه يأخذ كامل العرض */
        .select2-container {
            width: 100% !important;
        }

        /* .filter-bar-mobile select.form-control {
          height: 45px;
          min-width: 160px;
        } */

        .select2-container .select2-selection--single {
            height: 38px;
            padding: 6px 12px;
        }
    </style>



    @push('carlistingscript')
        {{-- Script related filters on carlisting page --}}
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

        <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

        <!-- Select2 CSS -->
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

        <!-- jQuery (مطلوب لـ Select2) -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <!-- Select2 JS -->
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


        <script>
            $(document).ready(function () {
                $('#filterFormMobile select').select2({
                    width: 'resolve',
                    minimumResultsForSearch: 0, // يجعل كل dropdown قابل للبحث
                    dropdownAutoWidth: true
                });
            });
        </script>


        <!-- <script>
                    $(document).ready(function() {
                        $('#brand').select2({
                            placeholder: "Select Make",
                            allowClear: true,
                            width: '100%',
                            height: '100%',

                        });

                        $('#model').select2({
                            placeholder: "Select Model",
                            allowClear: true,
                        width: '100%',
                            height: '100%',
                        });

                        $('#year').select2({
                            placeholder: "Select Year",
                            allowClear: true,
                       width: '100%',
                            height: '100%',
                        });
                    });


                </script> -->
        <script>
            $(document).ready(function () {
                // تفعيل select2 على جميع selectات داخل الفورم
                $('#filterForm select').select2({
                    // placeholder: "Select",
                    allowClear: true,
                    // width: '100%'
                });

                // تنفيذ الفلترة عند تغيير أي حقل
                $('#filterForm select').on('change', function () {
                    submitFilterForm();
                });
            });

            // دالة إرسال الفورم
            function submitFilterForm() {
                document.getElementById("filterForm").submit();
            }

            // دوال فتح/إغلاق مودال السعر
            function openModal() {
                document.getElementById("priceModal").style.display = "block";
            }

            function closeModal() {
                document.getElementById("priceModal").style.display = "none";
            }
        </script>


        <script>
            function submitFilterForm() {
                document.getElementById('filterFormMobile').submit();
            }
        </script>


        <script>
            // Open Modal
            function openModal() {
                document.getElementById("priceModal").style.display = "block";
            }

            // Close Modal
            function closeModal() {
                document.getElementById("priceModal").style.display = "none";
            }



            function submitFilterForm() {
                document.getElementById('filterForm').submit();
            }

            //  function submitFilterForm() {
            //     document.getElementById('filterFormMobile').submit();
            //   }

            function copyUrl(carUrl) {
                navigator.clipboard.writeText(carUrl).then(() => {
                    alert('URL copied: ' + carUrl);
                }).catch(err => {
                    console.error('Failed to copy URL: ', err);
                });
            }

            $(document).on('change', '#brand', function () {
                let brand = $(this).val();

                if (brand) {
                    $.ajax({
                        url: "{{ route('getModels') }}", // Adjust this route as needed
                        method: "POST",
                        data: {
                            brand: brand,
                            _token: $('meta[name="csrf-token"]').attr(
                                'content') // CSRF token for security
                        },
                        success: function (response) {
                            // console.log(response);

                            // Populate the child select box
                            $('#model').empty().append('<option value="">Select Model</option>');

                            response.models.forEach(function (model) {
                                let modelName = model ?? 'No Parent';

                                $('#model').append('<option value="' + modelName + '">' +
                                    modelName +
                                    '</option>');
                            });
                        },
                        error: function (xhr) {
                            console.error("Error fetching models:", xhr.responseText);
                        }
                    });
                } else {
                    // Reset the child select box if no item is selected
                    $('#model').empty().append('<option value="">model</option>');
                }
            });
        </script>
    @endpush
@endsection