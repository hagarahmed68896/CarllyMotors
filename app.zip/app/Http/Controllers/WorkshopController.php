<?php

namespace App\Http\Controllers;
use App\Models\WorkshopProvider;
use App\Models\WorkshopCategory;
use App\Models\CarBrand;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use DB;

class WorkshopController extends Controller
{
    public function index(Request $request)
    {
        $perPage    = request('perPage', 8);
        $currentUrl = url()->current();

        // Fetch distinct values for filters
        $cities = WorkshopProvider::select('branch')->distinct()->orderBy('branch')->pluck('branch');
        $brands   = DB::table('car_brand_workshop_provider')->distinct()->pluck('car_brand_id')->toArray();
        $brands = CarBrand::select('id', 'name')->whereIn('id', $brands)->distinct()->pluck('name', 'id')->toArray();

        $categories = DB::table('workshop_category_provider')->distinct()->pluck('workshop_category_id')->toArray();
        $categories = WorkshopCategory::select('id', 'name')->whereIn('id', $categories)->distinct()->pluck('name')->toArray();


        // Start the base query
        $query = WorkshopProvider::query();
        $query->inRandomOrder();
        // Apply filters
        if ($request->city) {
            $query->where('branch', $request->city);
        }

        if ($request->brand_id) {
            $brand = CarBrand::find($request->brand_id);
            $workshop_ids = $brand->providers()->pluck('workshop_provider_id')->toArray();
            // dd($workshop_ids);
            $query->whereIn('id', $workshop_ids);
            // dd($query->get());
        }

        if ($request->category_id) {
            $category = WorkshopCategory::find($request->category_id);
            $workshop_ids = $category->providers()->pluck('workshop_provider_id')->toArray();
            $query->whereIn('id', $workshop_ids);
        }

        // Paginate the results
        $workshops = $query->paginate($perPage);
        // $workshop = $query->first();
        // dd($workshop->days);
        // Return view with grouped data and other filter data
        return view('workshops.index', compact('cities', 'workshops','brands', 'categories'));

    }

    public function show(WorkshopProvider $workshop)
    {
        // Fetch distinct values for filters
        $cities = WorkshopProvider::select('branch')->distinct()->orderBy('branch')->pluck('branch');
        $brands   = DB::table('car_brand_workshop_provider')->distinct()->pluck('car_brand_id')->toArray();
        $brands = CarBrand::select('id', 'name')->whereIn('id', $brands)->distinct()->pluck('name', 'id')->toArray();

        $categories = DB::table('workshop_category_provider')->distinct()->pluck('workshop_category_id')->toArray();
        $categories = WorkshopCategory::select('id', 'name')->whereIn('id', $categories)->distinct()->pluck('name')->toArray();


        return view('workshops.show', compact('cities', 'workshop','brands', 'categories'));

    }
}
