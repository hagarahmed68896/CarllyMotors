<h2>Hey, It's me <?php echo e($data->name); ?></h2> 

<br>

    

<strong>User details: </strong><br>

<strong>Name: </strong><?php echo e($data->name); ?> <br>

<strong>Email: </strong><?php echo e($data->email); ?> <br>

<strong>Phone: </strong><?php echo e($data->phone); ?> <br>

<strong>Subject: </strong><?php echo e($data->subject); ?> <br>

<strong>Message: </strong><?php echo e($data->body); ?> <br><br>

  

Thank you<?php /**PATH /home/carllymotors.com/public_html/resources/views/contact-us/contact.blade.php ENDPATH**/ ?>