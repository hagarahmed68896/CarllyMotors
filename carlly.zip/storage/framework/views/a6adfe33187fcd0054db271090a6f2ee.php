<?php if($paginator->hasPages()): ?>
    <nav>
        <ul class="pagination justify-content-center">
            
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled">
                    <span class="page-link"><i class="fa fa-arrow-left "></i></span>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>">
                        <i class="fa fa-arrow-left "></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <li class="page-item <?php echo e($paginator->onFirstPage() ? 'active' : ''); ?>">
                <a class="page-link" href="<?php echo e($paginator->url(1)); ?>">1</a>
            </li>

            
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->url(2)); ?>">2</a>
            </li>

            
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->url(3)); ?>">3</a>
            </li>

            
            <?php if($paginator->currentPage() > 4): ?>
                <li class="page-item disabled"><span class="page-link">...</span></li>
            <?php endif; ?>

            
            <?php if($paginator->currentPage() > 3 && $paginator->currentPage() < $paginator->lastPage() - 2): ?>
                <li class="page-item active">
                    <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage())); ?>"><?php echo e($paginator->currentPage()); ?></a>
                </li>
            <?php endif; ?>

            
            <?php if($paginator->currentPage() < $paginator->lastPage() - 3): ?>
                <li class="page-item disabled"><span class="page-link">...</span></li>
            <?php endif; ?>

            
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->url($paginator->lastPage() - 1)); ?>"><?php echo e($paginator->lastPage() - 1); ?></a>
            </li>

            
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->url($paginator->lastPage())); ?>"><?php echo e($paginator->lastPage()); ?></a>
            </li>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>">
                        <i class="fa fa-arrow-right "></i>
                    </a>
                </li>
            <?php else: ?>
                <li class="page-item disabled">
                    <span class="page-link">
                        <i class="fa fa-arrow-right "></i>
                    </span>
                </li>
            <?php endif; ?>

        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH /home/carllymotors.com/public_html/resources/views/vendor/pagination/bootstrap-4.blade.php ENDPATH**/ ?>