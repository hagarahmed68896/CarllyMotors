<?php $__env->startSection('content'); ?>
<?php
$str = $sparePart->car_model;
$arr = json_decode($str, true);
$carModels = json_decode($arr, true);
?>

<!-- #strat breadcrums-->
<div class="car-list-details-breadcrums container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('home')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                Spare Part for sale
            </li>
        </ol>
    </nav>
    <hr />
</div>

<div class="container mt-4 listing-detail">
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div id="carCarousel" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <?php
                            $images = array_filter($images); // Remove null values -->
                            ?>

                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $image = Str::after($image, url('/').'/');
                            ?>
                            <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                <img src="<?php echo e(asset(env('FILE_BASE_URL').$image)); ?>" class="d-block w-100"
                                    alt="Car Image">

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <a class="carousel-control-prev" href="#carCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        </a>
                        <a class="carousel-control-next" href="#carCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        </a>
                    </div>
                    <ul class="nav nav-tabs mt-3" id="carTabs" role="tablist">
                        <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#overview" role="tab"
                                aria-selected="true">Overview</a></li>

                    </ul>
                    <div class="tab-content mt-3">
                        <div class="tab-pane fade active show" id="overview" role="tabpanel">
                            <h5 class="mt-3">Description</h5>
                            <p><?php echo e($sparePart->desc); ?></p>


                            <div class="overview-title mt-5">Overview</div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="overview-item">
                                        <i class="fas fa-car"></i>
                                        <span>Brand:</span>
                                        <span style="font-weight:bold"><?php echo e($sparePart->brand); ?></span>
                                    </div>

                                    <div class="overview-item">
                                        <i class="fas fa-barcode"></i>
                                        <span>VIN number:</span>
                                        <span style="font-weight:bold"><?php echo e($sparePart->vin_number); ?></span>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-calendar-alt"></i>
                                        
                                        <a data-bs-toggle="modal" data-bs-target="#yearsModal" href=""><span>Years</span></a>
                                        <!-- years Modal -->
                                        <div class="modal fade" id="yearsModal" tabindex="-1"
                                            aria-labelledby="yearsModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="yearsModalLabel">Years</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <ul>
                                                            <?php $__currentLoopData = json_decode($sparePart->year, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><?php echo e($year); ?></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-users"></i>
                                        <span>Model:</span>
                                        <span style="font-weight:bold"><?php echo e($sparePart->model); ?></span>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-city"></i>
                                        <span>City:</span>
                                        <span style="font-weight:bold"><?php echo e($sparePart->city); ?></span>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="overview-item">
                                        <i class="fas fa-cogs"></i>
                                        <span>Part Type:</span>
                                        <span style="font-weight:bold"><?php echo e($sparePart->part_type); ?></span>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-gas-pump"></i>
                                        <span class="text text-sm">Car Models:</span>
                                        <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                            <span style="font-weight:bold">view</span>
                                        </a>
                                        <div class="modal fade" id="exampleModal" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                            Car Models
                                                        </h1>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php $__currentLoopData = $carModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($model); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-door-closed"></i>
                                        <span>Engine:</span>
                                        <span style="font-weight:bold"><?php echo e($sparePart->engine); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="right-listing-detail-section">
                <!-- Car Details Section -->
                <div class="card">
                    <h4 class="mb-2"><?php echo e($sparePart->title); ?></h4>
                    <p class="text-muted mb-4">
                        <i class="fas fa-road"></i>
                        <?php echo e($sparePart->total_views); ?> views &nbsp;
                        <i class="fas fa-gas-pump"></i>
                        <?php echo e($sparePart->category->name); ?> &nbsp;
                        <br>

                        <i class="fas fa-user"></i>
                        <?php echo e($sparePart->user->fname); ?><?php echo e($sparePart->user->lname); ?>

                    </p>
                    <p class="price">AED <?php echo e($sparePart->price); ?></p>
                    <div class="icon-group mt-3">
                        <button title="add to fav" class="btn btn-outline-secondary"><i
                                class="fas fa-heart"></i></button>
                        <button title="copyUrl" onclick="copyUrl()" class="btn btn-outline-secondary">
                            <i class="fa fa-copy"></i>
                        </button>
                    </div>
                </div>

                <!-- Dealer Details Section -->
                <?php
                $userImage = Str::after($sparePart->user->image, url('/').'/');
                ?>
                <div class="card">

                    <div class="d-flex align-items-center mb-3">
                        <div class="rounded-circle bg-light" style="width: 60px; height: 60px;">
                            <img src="<?php echo e(env('FILE_BASE_URL'.$userImage)); ?>" alt="User-Image">
                        </div>
                        <div class="ml-3">
                            <h6 class=""><?php echo e($sparePart->user->fname . ' ' . $sparePart->user->lname); ?></h6>
                            <span class="verified-badge">Verified dealer</span>
                        </div>
                    </div>
                    <h6 class="mb-3">Contact Dealer</h6>

                    <div class="d-flex justify-content-between">
                        <a href="tel:<?php echo e($sparePart->user->phone); ?>"><button
                                class="contact-btn btn-call"><?php echo e($sparePart->user->phone); ?></button></a>
                    </div>
                </div>
            </div>

            <!-- <div class="report-list-car-right">
                <ul>
                    <li>
                        <a href="#"><i class="fa fa-light fa-flag"></i>Report this Dealer</a>
                    </li>
                </ul>
            </div> -->
        </div>
    </div>
</div>

<script>
function copyUrl() {
    const url = window.location.href; // Get current URL
    navigator.clipboard.writeText(url).then(() => {
        alert('URL copied to clipboard!' + url);
    }).catch(err => {
        console.error('Failed to copy URL: ', err);
    });
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\carr\resources\views\spareparts\show.blade.php ENDPATH**/ ?>