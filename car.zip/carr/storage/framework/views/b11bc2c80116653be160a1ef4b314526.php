<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/css/listing-detail.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">

</head>
<style>
.navbar-nav .nav-link {
    color: #fff;
}

.dropend .dropdown-toggle {
    color: #760e13;
    margin-left: 1em;
}

.dropdown-toggle::after {
    color: #760e13;
}

.dropdown-item:hover {
    background-color: #760e13;
    color: #fff;
    /* border-radius: 20%; */
 
}

.dropdown .dropdown-menu {
    display: none;
}

.dropdown-menu a:hover {
    text-decoration-color: #760e13;
    border-color: #760e13;
}

.dropdown-menu a:focus {
    border-color: #760e13;
}

.dropdown:hover>.dropdown-menu,
.dropend:hover>.dropdown-menu {
    display: block;
    margin-top: 0.125em;
    margin-left: 0.125em;
}

@media screen and (min-width: 769px) {
    .dropend:hover>.dropdown-menu {
        position: absolute;
        top: 0;
        left: 100%;
    }

    .dropend .dropdown-toggle {
        margin-left: 0.5em;
    }
}
</style>

<body class="relative h-screen bg-gray-100">
    <!-- Navbar -->
<nav class=" navbar navbar-expand-lg navbar-light bg-white shadow-sm py-2 ">
    <div class="container "> 
        <!-- Logo -->
        <a class="navbar-brand" href="#">
            <img src="<?php echo e(asset('carllymotorsmainlogo_dark.png')); ?>" alt="AutoDecar" class="img-fluid" style="height: 50px;">
        </a>

         <!-- Mobile Toggle Button -->
         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

        <!-- Navbar Links -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link fw-semibold text-dark" href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="nav-item"><a class="nav-link fw-semibold text-dark" href="<?php echo e(route('cars.index')); ?>">Cars</a></li>
                <li class="nav-item"><a class="nav-link fw-semibold text-dark" href="<?php echo e(route('spareParts.index')); ?>">Spare Parts</a></li>
                <li class="nav-item"><a class="nav-link fw-semibold text-dark" href="<?php echo e(route('aboutus')); ?>">About us</a></li>
                <li class="nav-item"><a class="nav-link fw-semibold text-dark" href="<?php echo e(route('contacts.index')); ?>">Contact</a></li>
            </ul>

            <!-- Icons & Buttons -->
            <div class="d-flex ">
    <?php if(auth()->check() == false): ?>
        <a class="btn custom-btn" href="<?php echo e(route('login')); ?>">Login</a>
    <?php else: ?>
        <a href="<?php echo e(route('cars.create')); ?>" class="btn custom-btn">
            <i class="fas fa-plus"></i> 
        </a>

        <a href="<?php echo e(route('cars.favList')); ?>" class="btn custom-btn">
            <i class="fas fa-heart"></i> 
        </a>

        <a class="btn custom-btn" href="#" role="button">Place Your AD</a>

        <div class="dropdown">
            <a class="btn custom-btn dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                aria-expanded="false">
                <i class="fas fa-user"></i> Profile
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li>
                    <a href="<?php echo e(route('profile', auth()->user()->id)); ?>" class="dropdown-item">Profile</a>
                </li>
                <li>
                    <form method="post" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="dropdown-item" type="submit">Logout</button>
                    </form>
                </li>
            </ul>
        </div>
    <?php endif; ?>
</div>



        </div>
    </div>
</nav>

<style>
    .nav-link:hover, .nav-link:focus, .nav-link.active {
        color: #760e13 !important;
    }

   
</style>
<style>
    .custom-btn {
        background: linear-gradient(135deg, #760e13, #a01b20);
        color: white;
        font-weight: bold;
        padding: 0.6em 1.5em;
        border-radius: 20px;
        margin-right: 0.2em;
        transition: background 0.3s ease, box-shadow 0.3s ease;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 16px;
    }

    .custom-btn:hover {
        background: linear-gradient(135deg, #8b1a1f, #b22226);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }

    .dropdown-menu {
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .dropdown-item {
        padding: 10px 15px;
        transition: background 0.2s ease;
    }

    .dropdown-item:hover {
        background: #8b1a1f;
    }
</style>

<style>
    .nav-link:hover, .nav-link:focus, .nav-link.active {
        color: #760e13 !important;
        font-weight: bold !important;
    }
    .icons:hover{
        color: #760e13 !important;
    }
</style>


    <!-- breadcrumd-listting -->

<!-- -->

    <?php echo $__env->yieldContent('content'); ?>

    <footer class="footer py-4">
        <div class="container">
            <!-- Top Icons -->
            

            <!-- Footer Links -->
            <div class="row footer-links mt-4 g-4 text-md-start">
                <div class='col-12 col-md-3'>
                <a href="#" class="footer-logo">
                            <img src="<?php echo e(asset('carllymotors_logo_white-2048x526.png')); ?>" alt="AutoDecar" class="img-fluid"
                                style="max-width: 150px;">
                        </a>
 <div class="col-md-6 text-md-end">
                        <div class="icons social-icons  d-flex justify-content-center justify-content-md-end gap-3 mt-3">
                            <a href="https://www.instagram.com/carllymotors?igsh=N3F5aHVpajd0ZnNk&utm_source=qr"><i
                                    class="fab fa-instagram fs-4" style="color:#fff ;"></i></a>
                            <a href="https://www.tiktok.com/@carllymotors"><i class="fab fa-tiktok fs-4"
                                    style="color:#fff"></i></a>
                            <a href="https://x.com/carllymotors?s=11&mx=2"><i class="fab fa-twitter fs-4"
                                    style="color:#fff"></i></a>
                            <a href="https://wa.me/971566350025"><i class="fab fa-whatsapp fs-4"
                                    style="color:#fff"></i></a>
                        </div>
            </div>
                </div>
                <div class="col-12 col-md-3">
                    <h5>About Auto Decar</h5>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('aboutus')); ?>">About us</a></li>
                        <li><a href="<?php echo e(route('contacts.index')); ?>">Contact us</a></li>
                        <li><a href="<?php echo e(route('terms')); ?>">Terms & Conditions</a></li>
                        <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                        
                    </ul>
                </div>
                <div class="col-12 col-md-3">
                    <h5>Popular Used Cars</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Chevrolet</a></li>
                        <li><a href="#">Ford</a></li>
                        <li><a href="#">Toyota</a></li>
                        <li><a href="#">BMW</a></li>
                    </ul>
                </div>
                <div class="col-12 col-md-3">
                    <h5>Newsletter</h5>
                    <p>Stay on top of the latest car trends, tips, and tricks for selling your car.</p>

                    <div class="input-group">
                        <input type="email" class="form-control" placeholder="Your email address"
                            aria-label="Your email address">
                        <button class="btn bg-carlly" type="button">Send</button>
                    </div>
                </div>
            </div>

            <!-- Footer Bottom -->
            <div class="footer-bottom mt-4">
                <div class="row">
                    <div class="col-md-12 mb-3 mb-md-0">
                        <!-- <a href="#" class="footer-logo">
                            <img src="<?php echo e(asset('carllymotorsmainlogo_dark.png')); ?>" alt="AutoDecar" class="img-fluid"
                                style="max-width: 150px;">
                        </a> -->
                        <p class="mt-2 d-flex justify-content-center">© 2025 Carlly Motors. All rights reserved</p>
                    </div>
                    <!-- <div class="col-md-6 text-md-end">
                        <div class="d-flex justify-content-center justify-content-md-end gap-5">
                            <a href="https://www.instagram.com/carllymotors?igsh=N3F5aHVpajd0ZnNk&utm_source=qr"><i
                                    class="fab fa-instagram fs-4" style="color:#fff"></i></a>
                            <a href="https://www.tiktok.com/@carllymotors"><i class="fab fa-tiktok fs-4"
                                    style="color:#fff"></i></a>
                            <a href="https://x.com/carllymotors?s=11&mx=2"><i class="fab fa-twitter fs-4"
                                    style="color:#fff"></i></a>
                            <a href="https://wa.me/971566350025"><i class="fab fa-whatsapp fs-4"
                                    style="color:#fff"></i></a>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <?php echo $__env->yieldPushContent('carlistingscript'); ?>
    
    <script>
    $(document).ready(function() {
        // Toggle the icon when accordion is expanded/collapsed
        $('.accordion-button').on('click', function() {
            const icon = $(this).find('.icon');
            const isExpanded = $(this).attr('aria-expanded') === 'true';

            // Remove rotate class from all icons
            $('.icon').removeClass('rotate');

            // Add rotate class if this item is expanded
            if (!isExpanded) {
                icon.addClass('rotate');
            }
        });
    });
    document.addEventListener("DOMContentLoaded", function() {
        let currentUrl = window.location.href;
        document.querySelectorAll(".nav-link").forEach(link => {
            if (link.href === currentUrl) {
                link.classList.add("active");
            }
        });
    });
    </script>

</body>

</html>
<!--can you tell me in many details and explian it --><?php /**PATH D:\PROJECTS\carr\resources\views/layouts/app.blade.php ENDPATH**/ ?>