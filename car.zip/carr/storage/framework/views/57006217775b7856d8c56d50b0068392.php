<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Swiper.js CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
    integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
</style>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php $__env->startSection('page'); ?>

<div class="filter-bar my-2">
    <form class="form-row" method="get">
        <!-- City Dropdown -->
        <div class="col-">
            <select class="form-control" name="city">
                <option value="" selected>City</option>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($city != null || $city != ''): ?>
                <option value="<?php echo e($city); ?>" <?php echo e(request('city') == $city ? 'selected' : ''); ?>>
                    <?php echo e($city); ?>

                </option>
                <?php else: ?>
                <?php continue; ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
       

        <!-- Make Dropdown -->
        <div class="col-">
            <select class="form-control" name="make">
                <option value="" selected>Make</option>
                <?php $__currentLoopData = $makes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($make); ?>" <?php echo e(request('make') == $make ? 'selected' : ''); ?>>
                    <?php echo e($make); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Model Dropdown -->
        <div class="col-">
            <select class="form-control" name="model">
                <option value="" selected>Model</option>
                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($model != null || $model != ''): ?>
                <option value="<?php echo e($model); ?>" <?php echo e(request('model') == $model ? 'selected' : ''); ?>>
                    <?php echo e($model); ?>

                </option>
                <?php else: ?>
                <?php continue; ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Year Dropdown -->
        <div class="col-">
            <select class="form-control" name="year">
                <option value="" selected>Year</option>
                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year); ?>" <?php echo e(request('year') == $year ? 'selected' : ''); ?>>
                    <?php echo e($year); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Body Type Dropdown -->
        <div class="col-">
            <select class="form-control" name="category">
                <option value="" selected>Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category); ?>" <?php echo e(request('category') == $category ? 'selected' : ''); ?>>
                    <?php echo e($category); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Brands Dropdown -->
        <div class="col-">
            <select class="form-control" name="brand">
                <option value="" selected>Brands</option>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($brand->name); ?>" <?php echo e(request('brand') == $brand->name ? 'selected' : ''); ?>>
                    <?php echo e($brand->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Price Dropdown -->
        <div class="col-">
            <select class="form-control" name="price">
                <option value="" selected>Price</option>
                <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($price != null || $price != ''): ?>
                <option value="<?php echo e($price); ?>" <?php echo e(request('price') == $price ? 'selected' : ''); ?>>
                    <?php echo e($price); ?>

                </option>
                <?php else: ?>
                <?php continue; ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Search Button -->
        <div class="col-">
            <button type="submit" class="btn btn-block">Search</button>
        </div>
    </form>
</div>

<div class="tab-content" id="bodyTypeTabsContent">
    <div class="container main-car-list-sec">
        <div class="row">
            <?php $__currentLoopData = $spareParts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3 col-sm-12 col-md-6 col-lg-4 col-xl-3">
                <div class="car-card border-0">
                    <div id="carouselExample_<?php echo e($key); ?>" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <?php if(count($part->images) != 0): ?>
                            <?php $__currentLoopData = $part->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $image = Str::after($image->image, url('/').'/');
                            ?>
                            <div class="carousel-item active">
                                <img src="<?php echo e(config('app.file_base_url') . $image); ?>" class="d-block w-100"
                                    style="height: 219px;object-fit: cover;" alt="Car Image">
                                <div class="badge-featured">Featured</div>
                                <div class="badge-images"><img src="<?php echo e(config('app.file_base_url') . $image); ?>"
                                        alt="icon"> 6
                                </div>
                                <div class="badge-year"><?php echo e($part->brand); ?></div>
                                <div class="overlay">
                                    <div class="icon-btn">
                                        <a href="#"><img src="https://carllymotors.com/demo/images/faviourt-icon.png"
                                                alt="Favorite"></a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <div class="carousel-item active">
                                <img src="https://backend.carllymotors.com/public/icon/sparepart.jpg" class="d-block w-100"
                                    style="height: 219px;object-fit: cover;" alt="Car Image">
                                <div class="badge-featured">Featured</div>
                                <div class="badge-images"><img src="https://backend.carllymotors.com/public/icon/sparepart.jpg"
                                        alt="icon"> 6
                                </div>
                                <div class="badge-year"><?php echo e($image); ?></div>
                                <div class="overlay">
                                    <div class="icon-btn">
                                        <a href="#"><img src="https://carllymotors.com/demo/images/faviourt-icon.png"
                                                alt="Favorite"></a>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <!-- Add carousel controls -->
                        <a class="carousel-control-prev" href="#carouselExample_<?php echo e($key); ?>" role="button"
                            data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExample_<?php echo e($key); ?>" role="button"
                            data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                    <div class="car-list-content-sec">
                        <span class="featured"><?php echo e($part->model); ?></span>

                        <h5 class="car-listing-title"> <?php echo e($part->title); ?></h5>

                        <p class="price">AED <?php echo e(number_format($part->price, 2)); ?></p>
                        <?php if($part->user): ?>
                        <?php
                        $path = parse_url($part->user->image, PHP_URL_PATH);
                        $image = ltrim($path, '/');
                        ?>

                        <div class="row profile-home-pic-sec" style="margin:10px">
                            <div class="col-sm-8 d-flex p-0">
                                <div class="left-pic">
                                    <!-- <img class="w-100"  style="border-radius: 100%"
                                        src="<?php echo e($part->user ? config('app.file_base_url') . $image : 'https://www.shutterstock.com/image-vector/user-profile-icon-vector-avatar-600nw-2220431045.jpg'); ?>"
                                        alt=""> -->
                                </div>
                                <div class="right-text align-items-center">
                                    <p><a href="https://wa.me/<?php echo e($part->user->phone); ?>" target="_blank"><?php echo e($part->user ? $part->user->fname . ' ' . $part->user->lname : ""); ?> </a></p>
                                </div>
                            </div>
                            <div class="col-sm-4 p-0 d-flex align-items-center">
                                <a href="<?php echo e(route('spareParts.show', $part->id)); ?>" 
                                    class="btn btn-view" >Details</a>

                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\carr\resources\views\spareparts\homeSection.blade.php ENDPATH**/ ?>