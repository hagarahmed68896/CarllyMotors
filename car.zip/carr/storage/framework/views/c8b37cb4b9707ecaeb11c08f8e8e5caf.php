<?php $__env->startSection('content'); ?>

<head>
    <style>
    #map {
        height: 400px;
        width: 100%;
        cursor: pointer;
    }

    /* Fullscreen Map Styles */
    #fullMapModal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.9);
        z-index: 1000;
        display: none;
    }

    #fullMap {
        height: 100%;
        width: 100%;
    }

    .close-btn {
        position: absolute;
        top: 20px;
        right: 30px;
        font-size: 30px;
        color: white;
        cursor: pointer;
        z-index: 1100;
    }

    .btn-outline-danger {
        /* background-color: #760e13 !important; */
        color: #760e13 !important;
        border-color: #760e13 !important;
    }

    .btn-outline-danger:hover {
        background-color: #5a0b0f !important;
        border-color: #5a0b0f !important;
        color: #f3f3f3 !important;
    }
    </style>

</head>
<!-- #strat breadcrums-->
<div class="car-list-details-breadcrums container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Home</a>
            </li>
            <li class="breadcrumb-item" aria-current="page">
                Used cars for sale
            </li>
        </ol>
    </nav>
    <hr />
</div>

<div class="container mt-4 listing-detail">
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div id="carCarousel" class="carousel slide rounded-2" data-ride="carousel">
                        <div class="carousel-inner">
                            <?php
                            $images = [
                            $car->listing_img1,
                            $car->listing_img2,
                            $car->listing_img3,
                            $car->listing_img4,
                            $car->listing_img5
                            ];
                            $images = array_filter($images); // Remove null values
                            ?>

                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                <img src="<?php echo e(asset(env("FILE_BASE_URL").$image)); ?>" class="d-block w-100 h-40"
                                    alt="Car Image">

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <a class="carousel-control-prev" href="#carCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        </a>
                        <a class="carousel-control-next" href="#carCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        </a>
                    </div>
                    <ul class="nav nav-tabs mt-3" id="carTabs" role="tablist" >
                        <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#overview" role="tab"
                                aria-selected="true">Overview</a></li>

                    </ul>
                    <!-- <div class="tab-content mt-3" style="margin-left:5px; margin-right:5px;">
                        <div class="tab-pane fade active show" id="overview" role="tabpanel">
                            <h5 class="mt-3">Description</h5>
                            <p><?php echo e($car->listing_desc); ?></p>


                            <div class="overview-title mt-5">Car Overview</div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="overview-item">
                                        <i class="fas fa-car"></i>
                                        <span>Condition:</span>
                                        <span class="value"><?php echo e($car->car_type); ?></span>
                                    </div>

                                    <div class="overview-item">
                                        <i class="fas fa-barcode"></i>
                                        <span>VIN number:</span>
                                        <span class="value"><?php echo e($car->vin_number); ?></span>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-calendar-alt"></i>
                                        <span>Year:</span>
                                        <span class="value"><?php echo e($car->listing_year); ?></span>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-users"></i>
                                        <span>Seats:</span>
                                        <span class="value"><?php echo e($car->features_seats); ?></span>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-city"></i>
                                        <span>City:</span>
                                        <span class="value"><?php echo e($car->city); ?></span>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="overview-item">
                                        <i class="fas fa-cogs"></i>
                                        <span>Cylinders:</span>
                                        <span class="value"><?php echo e($car->features_cylinders); ?></span>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-gas-pump"></i>
                                        <span>Fuel Type:</span>
                                        <span class="value"><?php echo e($car->features_fuel_type); ?></span>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-door-closed"></i>
                                        <span>Doors:</span>
                                        <span class="value"><?php echo e($car->features_door); ?></span>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-palette"></i>
                                        <span>Color:</span>
                                        <span class="value"><?php echo e($car->color?->name); ?></span>
                                    </div>
                                    <div class="overview-item">
                                        <i class="fas fa-cog"></i>
                                        <span>Transmission:</span>
                                        <span class="value"><?php echo e($car->features_gear); ?></span>
                                    </div>
                                    
                                </div>
                            </div>

                            <div class="features-title mt-5">Features</div>
                            <?php if(!empty($car->features_others)): ?>
                            <?php
                            // Convert the JSON string to an array
                            $features = json_decode($car->features_others, true);
                            ?>
                            <?php if(is_array($features) && count($features) > 0): ?>
                            <div class="row">
                                <?php $__currentLoopData = array_chunk($features, ceil(count($features) / 3)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <?php $__currentLoopData = $column; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="feature-item">
                                        <i class="fas fa-check-circle"></i>
                                        <span><?php echo e(trim($feature)); ?></span>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php else: ?>
                            <p>No features available.</p>
                            <?php endif; ?>
                            <?php else: ?>
                            <p>No features available.</p>
                            <?php endif; ?>

                        </div>
                    </div> -->

     <div class="container mt-4" style="margin-top:10px;">
                       <div class="tab-content " style="margin-bottom:10px;">
              <div class="tab-pane fade active show" id="overview" role="tabpanel">
                            <h3 class="overview-title mt-3">Description</h3>
                            <p><?php echo e($car->listing_desc); ?></p>

            <h4 class="mt-4 overview-title">Car Overview</h4>
            <div class="row">
                <div class="col-md-6">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item  overview-item" ><i class="fas fa-car "></i> <strong>Condition:</strong><span class="fs-3 pl-2"> <?php echo e($car->car_type); ?></span> </li>
                        <li class="list-group-item  overview-item"><i class="fas fa-barcode"></i> <strong>VIN number:</strong><span class="fs-3 pl-2"> <?php echo e($car->vin_number); ?></span>  </li>
                        <li class="list-group-item  overview-item"><i class="fas fa-calendar-alt"></i> <strong>Year:</strong><span class="fs-3 pl-2"> <?php echo e($car->listing_year); ?></span></li>
                        <li class="list-group-item  overview-item"><i class="fas fa-users"></i> <strong>Seats:</strong><span class="fs-3 pl-2"><?php echo e($car->features_seats); ?></span> </li>
                        <li class="list-group-item  overview-item"><i class="fas fa-city"></i> <strong>City:</strong><span class="fs-3 pl-3"> <?php echo e($car->city); ?> </span></li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item  overview-item"><i class="fas fa-cogs"></i> <strong>Cylinders:</strong><span class="fs-3 pl-2">  <?php echo e($car->features_cylinders); ?> </span></li>
                        <li class="list-group-item  overview-item"><i class="fas fa-gas-pump"></i> <strong>Fuel Type:</strong><span class="fs-3 pl-2"> <?php echo e($car->features_fuel_type); ?></span></li>
                        <li class="list-group-item  overview-item"><i class="fas fa-door-closed"></i> <strong>Doors:</strong> <span class="fs-3 pl-2"> <?php echo e($car->features_door); ?> </span></li>
                        <li class="list-group-item  overview-item"><i class="fas fa-palette"></i> <strong>Color:</strong> <span class="fs-3 pl-2">  <?php echo e($car->color?->name); ?> </span></li>
                        <li class="list-group-item  overview-item"><i class="fas fa-cog"></i> <strong>Transmission:</strong><span class="fs-3 pl-2">  <?php echo e($car->features_gear); ?> </span></li>
                    </ul>
                </div>
            </div>

            <h4 class="mt-4">Features</h4>
            <?php if(!empty($car->features_others)): ?>
                <?php $features = json_decode($car->features_others, true); ?>
                <?php if(is_array($features) && count($features) > 0): ?>
                    <div class="row">
                        <?php $__currentLoopData = array_chunk($features, ceil(count($features) / 3)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $column; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> <?php echo e(trim($feature)); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p>No features available.</p>
                <?php endif; ?>
            <?php else: ?>
                <p>No features available.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="right-listing-detail-section">
                <!-- Car Details Section -->
                <div class="card">
                    <h4 class="mb-2"><?php echo e($car->listing_type); ?> | <?php echo e($car->listing_model); ?></h4>
                    <p class="text-muted mb-4">
                        <i class="fas fa-road"></i>
                        <?php echo e($car->features_speed); ?> kms &nbsp;
                        <i class="fas fa-gas-pump"></i>
                        <?php echo e($car->features_fuel_type); ?> &nbsp;
                        <br>
                        <i class="fas fa-cogs"></i>
                        <?php echo e($car->features_gear); ?> &nbsp;
                        <i class="fas fa-user"></i>
                        <?php echo e($car->user?->fname); ?> <?php echo e($car->user?->lname); ?>

                    </p>
                    <p class="price" style="color:#760e13">AED <?php echo e($car->listing_price); ?></p>
                    <?php if(auth()->check()): ?>
                    <?php
                        $favCars = auth()->user()->favCars()->pluck('id')->toArray();
                    ?>
                    <div class="icon-group mt-3">
                        <form action="<?php echo e(route('cars.addTofav', $car->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button title="add to fav" class="btn btn-sm"  type="submit">
                                <i class="fas fa-heart" style="color:<?php echo e(in_array($car->id, $favCars) ? '#760e13' : 'gray'); ?>"></i>
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Dealer Details Section -->
                <div class="card">
                    <div class="d-flex align-items-center mb-3">
                        
                    <div class="ml-3">
                        <h6 class="">Car Empire</h6>
                        <span class="verified-badge">Verified dealer</span>
                    </div>
                </div>
                <p class="text-muted"> <?php echo e($car->user?->location); ?></p>
                <div class="bg-light rounded mb-3" id="map" onclick="openFullMap()" style="height: 100px;"></div>
                <div id="fullMapModal">
                    <span class="close-btn" onclick="closeFullMap()">&times;</span>
                    <div id="fullMap"></div>
                </div>
                <h6 class="mb-3">Contact dealer</h6>
                <div class="d-flex justify-content-between">
                    <a href="https://wa.me/<?php echo e($car->user?->phone); ?>" target="_blank">
                        <button class="btn btn-outline-danger" style="border-radius: 25px;">
                            <i class="fab fa-whatsapp"></i> WhatsApp
                        </button>
                    </a>
                    <?php if($os == 'Windows' || $os == 'Linux' ): ?>
                    <a href="https://wa.me/<?php echo e($car->user?->phone); ?>" target="_blank">
                        <button class="btn btn-outline-danger" style="border-radius: 25px;">
                            <i class="fa fa-phone"></i> Call
                        </button>
                    </a>
                    <?php elseif($os == 'Mac'): ?>
                    <a href=<?php echo e('https://faceapp.com?phone=' . urlencode($car->user?->phone)); ?>>
                        <button class="btn btn-outline-danger" style="border-radius: 25px;">
                            <i class="fa fa-phone"></i> Call
                        </button>
                    </a>
                    <?php elseif($os == 'Android' || $os='iOS'): ?>
                    <a href="tel:<?php echo e($car->user?->phone); ?>">
                        <button class="btn btn-outline-danger" style="border-radius: 25px;">
                            <i class="fa fa-phone"></i> Call
                        </button>
                    </a>
                    <?php else: ?>
                    No OS Detected
                    <?php endif; ?>
                    <a href=" https://wa.me/?text=<?php echo e(urlencode('Hello, i recommend you to check this car ' . route('car.detail', [ Crypt::encrypt($car->id)]))); ?>"
                        target="_blank">
                        <button class="btn btn-outline-danger" style="border-radius: 25px;">
                            <i class="fa fa-share"></i>
                            Share
                        </button>
                    </a>
                </div>
            </div>
        </div>

        <div class="report-list-car-right">
            <ul>
                <li>
                    <a href="#"><i class="fa fa-light fa-flag"></i>Report this listing</a>
                </li>
            </ul>
        </div>
        <div class="container my-4 recmended-used-car-section px-0">
            <!-- Recommended Cars Section -->
            <div class="card">
                <h5>Recommended Used Cars</h5>
                <p class="text-muted">Showing <?php echo e(count($recommendedCars)); ?> more cars you might like</p>
                <ul class="car-list">
                    <?php $__currentLoopData = $recommendedCars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendedCar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <a href="<?php echo e(route('car.detail', [ Crypt::encrypt($recommendedCar->id)])); ?>">
                        <li class="car-list-item">
                            <div class="car-image">
                                <!-- Display the car image -->
                                <img src="<?php echo e(env('FILE_BASE_URL') . $recommendedCar->listing_img1); ?>" alt="Car Image"
                                    class="img-fluid">
                            </div>
                            <div class="text-list-para">
                                <p class="car-title"><?php echo e($recommendedCar->listing_year); ?>

                                    <?php echo e($recommendedCar->listing_type); ?> <?php echo e($recommendedCar->listing_model); ?></p>
                                <p class="car-price"><?php echo e('AED ' . number_format($recommendedCar->listing_price)); ?>

                                </p>
                            </div>
                        </li>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>

        </div>
    </div>
</div>
</div>

<script>
function copyUrl() {
    const url = window.location.href; // Get current URL
    navigator.clipboard.writeText(url).then(() => {
        alert('URL copied to clipboard!' + url);
    }).catch(err => {
        console.error('Failed to copy URL: ', err);
    });
}
</script>
<script
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAg11eAiAzKB6kMmJXfRbElSfK96RkDVq4&callback=initMap&libraries=maps,marker"
    async defer></script>

<script>
function copyUrl() {
    const url = window.location.href; // Get current URL
    navigator.clipboard.writeText(url).then(() => {
        alert('URL copied : ' + url);
    }).catch(err => {
        console.error('Failed to copy URL: ', err);
    });
}
var latitude = <?php echo e($car->lat); ?>

var longitude = <?php echo e($car->lng); ?>


// Initialize Small Map
function initSmallMap() {
    var location = {
        lat: latitude,
        lng: longitude
    };
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 13,
        center: location,
    });
    var marker = new google.maps.Marker({
        position: location,
        map: map,
        title: "Selected Location",
    });
}

// Function to open Fullscreen Map
function openFullMap() {
    document.getElementById('fullMapModal').style.display = 'block';

    var location = {
        lat: latitude,
        lng: longitude
    };
    var fullMap = new google.maps.Map(document.getElementById('fullMap'), {
        zoom: 15,
        center: location,
    });
    new google.maps.Marker({
        position: location,
        map: fullMap,
        title: "Selected Location",
    });
}

// Function to close Fullscreen Map
function closeFullMap() {
    document.getElementById('fullMapModal').style.display = 'none';
    document.getElementById('fullMap').innerHTML = ''; // Clear Full Map
}

// Initialize Small Map on Load
window.onload = initSmallMap;
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\carr\resources\views/cars/show.blade.php ENDPATH**/ ?>