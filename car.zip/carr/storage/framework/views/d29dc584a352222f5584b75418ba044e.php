<?php
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;

?>
<?php $__env->startSection('content'); ?>

<!-- breadcrumd-listting -->
<div class="container-fluid border-line-list-car">
    <div class="row">
        <div class="col-sm-12">
            <ul class="breadcrums-list-car">
                <li>
                    <a style="color: #760e13;" href="">Home > </a>
                </li>
                <li class="used-car-text">
                    Used cars for sale
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- Header Section -->
<div class="header-section">
    <h2>10,000+ Get The Best Deals On Used Cars</h2>
    <p>Explore our selection of high-quality, pre-owned vehicles. Our inventory includes top brands like Toyota,
        Mercedes, Honda, and more.</p>
</div>

<!-- Main Content -->
<div class="container">
    <div class="row">
        <!-- Filter Sidebar -->
        <div class="col-md-3">
            <div class="filter-sidebar">
                <h5>Filters and Sort</h5>
                <hr>
                <form id="filterForm" method="GET" action="<?php echo e(route('filter.cars')); ?>">
                    <!-- Make -->
                    <div class="form-group">
                        <label>Make</label>
                        <select class="form-control" name="make" id="make" onchange="submitFilterForm()">
                            <option value="">Select Make</option>
                            <?php $__currentLoopData = $makes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($make); ?>" <?php echo e(request('make') == $make ? 'selected' : ''); ?>><?php echo e($make); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <!-- Model -->
                    <div class="form-group">
                        <label>Model</label>
                        <select class="form-control" name="model" id="model" onchange="submitFilterForm()">
                            <option value="">Select Model</option>
                            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($model); ?>" <?php echo e(request('model') == $model ? 'selected' : ''); ?>><?php echo e($model); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Price Range -->
                    <div class="form-group">
                        <label for="priceRange">Price: <span id="priceValue"><?php echo e(request('price', $minPrice)); ?></span></label>
                        <input
                            type="range"
                            class="form-control-range"
                            id="priceRange"
                            min="<?php echo e($minPrice); ?>"
                            max="<?php echo e($maxPrice); ?>"
                            value="<?php echo e(request('price', $minPrice)); ?>"
                            name="price"
                            oninput="updatePriceValue(this.value); submitFilterForm()">
                    </div>
                    <!-- <input type="hidden" id="priceHidden" name="price" value=""> -->

                    <!-- Fuel Type -->
                    <div class="form-group">
                        <label>Fuel Type</label>
                        <select class="form-control" name="fuel_type" id="fuel_type" onchange="submitFilterForm()">
                            <option value="">Select Fuel Type</option>
                            <?php $__currentLoopData = $fueltypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fueltype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fueltype); ?>" <?php echo e(request('fuel_type') == $fueltype ? 'selected' : ''); ?>><?php echo e($fueltype); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Transmission -->
                    <div class="form-group">
                        <label>Transmission</label>
                        <select class="form-control" name="transmission" id="transmission" onchange="submitFilterForm()">
                            <option value="">Select Transmission</option>
                            <?php $__currentLoopData = $gears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gear); ?>" <?php echo e(request('transmission') == $gear ? 'selected' : ''); ?>><?php echo e($gear); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Driver Type -->
                    <div class="form-group">
                        <label>Driver Type</label>
                        <select class="form-control" name="driver_type" id="driver_type" onchange="submitFilterForm()">
                            <option value="" <?php echo e(request('driver_type') == 'Automatic' ? 'selected' : ''); ?>>Automatic</option>
                            <option value="" <?php echo e(request('driver_type') == 'Manual' ? 'selected' : ''); ?>>Manual</option>
                        </select>
                    </div>

                    <!-- Door -->
                    <div class="form-group">
                        <label>Door</label>
                        <select class="form-control" name="door" id="door" onchange="submitFilterForm()">
                            <option value="">Select Door</option>
                            <?php $__currentLoopData = $doors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $door): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($door); ?>" <?php echo e(request('door') == $door ? 'selected' : ''); ?>><?php echo e($door); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Cylinder -->
                    <div class="form-group">
                        <label>Cylinder</label>
                        <select class="form-control" name="cylinder" id="cylinder" onchange="submitFilterForm()">
                            <option value="">Select Cylinders</option>
                            <?php $__currentLoopData = $cylinders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cylinder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cylinder); ?>" <?php echo e(request('cylinder') == $cylinder ? 'selected' : ''); ?>><?php echo e($cylinder); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Color -->
                    <div class="form-group">
                        <label>Color</label>
                        <select class="form-control" name="color" id="color" onchange="submitFilterForm()">
                            <option value="">Select Color</option>
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($color); ?>" <?php echo e(request('color') == $color ? 'selected' : ''); ?>><?php echo e($color); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Year -->
                    <div class="form-group">
                        <label for="yearRange">
                            Year: <span id="yearValue"><?php echo e(request('year', $minYear)); ?></span>
                        </label>
                        <input
                            type="range"
                            class="form-control-range"
                            id="yearRange"
                            min="<?php echo e($minYear); ?>"
                            max="<?php echo e($maxYear); ?>"
                            value="<?php echo e(request('year', $minYear)); ?>"
                            name="year"
                            oninput="updateYearValue(this.value); submitFilterForm()">
                    </div>
                    <!-- <input type="hidden" id="yearHidden" name="year" value=""> -->

                    <!-- Distance -->
                    <div class="form-group">
                        <label for="distanceRange">
                            Distance: <span id="distanceValue"><?php echo e(request('distance')); ?></span>kms
                        </label>
                        <input
                            type="range"
                            class="form-control-range"
                            id="distanceRange"
                            value="<?php echo e(request('distance')); ?>"
                            name="distance"
                            oninput="updateDistanceValue(this.value); submitFilterForm()">
                    </div>
                    <input type="hidden" id="distanceHidden" name="distance" value="">
                </form>
            </div>
        </div>
        <!-- Car Listings -->
        <div class="col-md-9">
            <div class="row">
                <!-- Car Item filters-->
                <div class="col-md-12">
                    <div class="filter-bar d-flex flex-wrap">
                        <div class="results-count">Showing <?php echo e($carlisting->firstItem()); ?>-<?php echo e($carlisting->lastItem()); ?> of <?php echo e($carlisting->total()); ?> results</div>
                        <div class="d-flex ml-auto">
                            <!-- View Toggle Buttons -->
                            <div class="view-buttons">
                                <a href="<?php echo e(route('listing.grid')); ?>" class="btn"><i class="fas fa-th"></i></a>
                                <a href="<?php echo e(route('carlisting')); ?>" class="btn"><i class="fas fa-bars"></i></a>
                            </div>

                             <!-- Show Per Page Dropdown -->
                            <form method="GET" action="<?php echo e(url()->current()); ?>" class="d-flex align-items-center justify-content-between mb-3">
                                <!-- Show Per Page Dropdown -->
                                <div class="d-flex align-items-center ml-3">
                                    <label for="perPage" class="mr-2">Show:</label>
                                    <select name="perPage" id="perPage" class="custom-select" style="width: auto;" onchange="this.form.submit()">
                                        <option value="10" <?php echo e(request('perPage') == 10 ? 'selected' : ''); ?>>10</option>
                                        <option value="20" <?php echo e(request('perPage') == 20 ? 'selected' : ''); ?>>20</option>
                                        <option value="50" <?php echo e(request('perPage') == 50 ? 'selected' : ''); ?>>50</option>
                                        <option value="100" <?php echo e(request('perPage') == 100 ? 'selected' : ''); ?>>100</option>
                                    </select>
                                </div>
                                <div class="d-flex align-items-center ml-3">
                                    <label for="sortBy" class="mr-2">Sort by:</label>
                                    <select name="sortBy" id="sortBy" class="custom-select" style="width: auto;" onchange="this.form.submit()">
                                        <option value="default" <?php echo e(request('sortBy') == 'default' ? 'selected' : ''); ?>>Sort by (Default)</option>
                                        <option value="Price: Low to High" <?php echo e(request('sortBy') == 'Price: Low to High' ? 'selected' : ''); ?>>Price: Low to High</option>
                                        <option value="Price: High to Low" <?php echo e(request('sortBy') == 'Price: High to Low' ? 'selected' : ''); ?>>Price: High to Low</option>
                                        <option value="Newest" <?php echo e(request('sortBy') == 'Newest' ? 'selected' : ''); ?>>Newest</option>
                                        <option value="Oldest" <?php echo e(request('sortBy') == 'Oldest' ? 'selected' : ''); ?>>Oldest</option>
                                    </select>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <!-- Car Item listing -->
                <?php if($carlisting->isNotEmpty()): ?>
                    <?php $__currentLoopData = $carlisting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $user = $car->user;
                        ?>
                        <div class="col-md-12">
                            <div class="car-list-sec">
                                <div class="row">
                                     <div class="col-md-5 pr-0">
                                        <div class="car-card border-0 p-3" >
                                            <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                                <div class="carousel-inner">
                                                    <?php $__currentLoopData = [$car->listing_img1, $car->listing_img2, $car->listing_img3, $car->listing_img4, $car->listing_img5]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($image): ?>
                                                            <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                                                <div class="badge-featured">Featured</div>
                                                                <div class="badge-images">
                                                                    <img src="<?php echo e(config('app.file_base_url') . $image); ?>" alt="Car Image">
                                                                </div>
                                                                <div class="badge-year"><?php echo e($car->listing_year); ?></div>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <a class="carousel-control-prev" href="#carouselExample" role="button"
                                                    data-slide="prev">
                                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                    <span class="sr-only">Previous</span>
                                                </a>
                                                <a class="carousel-control-next" href="#carouselExample" role="button"
                                                    data-slide="next">
                                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                    <span class="sr-only">Next</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 pl-0">
                                        <span class="featured"><?php echo e($car->cities); ?></span>
                                        <h5 class="car-listing-title"><?php echo e($car->listing_title); ?></h5>
                                        <p><?php echo e($car->features_speed); ?>kms | <?php echo e($car->features_fuel_type); ?> | <?php echo e($car->features_gear); ?></p>
                                        <p class="price">$<?php echo e($car->listing_price); ?></p>
                                        <a href=" <?php echo e(route('car.detail', [Crypt::encrypt($car->id)])); ?>" class="btn btn-view">View Details</a>
                                    </div>
                                    <div class="col-md-3 pl-0 ">
                                        <div class="chat-card shadow-none border-0">
                                            <div class="row">
                                                <div class="col-sm-4 pr-0 border-0">
                                                    <?php if(isset($car->user)): ?>
                                                        <img src="<?php echo e(config('app.file_base_url'). $user->image); ?>" alt="User Profile">
                                                    <?php else: ?>
                                                        <img src="https://www.shutterstock.com/image-vector/user-profile-icon-vector-avatar-600nw-2220431045.jpg" alt="Default User Profile">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-sm-8 text-left border-0">
                                                    <?php if(isset($car->user)): ?>
                                                        <h6><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></h6>
                                                        <p><?php echo e($user->created_at); ?></p>
                                                    <?php else: ?>
                                                        <h6>User not available</h6>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <button class="btn chat-btn border-0"><i class="far fa-comment-dots"></i>
                                                Chat</button>
                                            <p>View 20 variants matching your search criteria</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="col-12">
                        <p class="text-center">No cars found.</p>
                    </div>
                <?php endif; ?>

            </div>
            <div class="pagination-links mb-0 d-flex justify-content-center" style="margin: 0;">
                <?php echo e($carlisting->appends(['perPage' => request('8')])->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('carlistingscript'); ?>
    
    <script>
        function submitFilterForm() {
            document.getElementById('filterForm').submit();
        }
        //Update the Year value display
        function updateYearValue(value) {
        let yearValue = document.getElementById('yearValue');
        let yearHidden = document.getElementById('yearHidden');

        if (value === "" || value == <?php echo e($minYear); ?>) {
            yearValue.innerText = "Any";
            yearHidden.value = "";  // Ensure NULL is sent if not selected
        } else {
            yearValue.innerText = value;
            yearHidden.value = value;
        }}

        // Update the distance value display

        // Update the price value display
        function updatePriceValue(value) {
        let priceValue = document.getElementById('priceValue');
        let priceHidden = document.getElementById('priceHidden');

        if (value === "" || value == <?php echo e($minPrice); ?>) {
            priceValue.innerText = "Any";
            priceHidden.value = "";  // Ensuring NULL is sent if not selected
        } else {
            priceValue.innerText = value;
            priceHidden.value = value;
        }
    }
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\carr\resources\views\carlisting.blade.php ENDPATH**/ ?>