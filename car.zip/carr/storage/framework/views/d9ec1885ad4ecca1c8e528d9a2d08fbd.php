<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coming Soon</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
        }

        .bgimg {
            height: 100%;
            background-position: center;
            background-size: cover;
            position: relative;
            color: white;
            font-family: "Courier New", Courier, monospace;
            font-size: 25px;
        }

        .topleft {
            position: absolute;
            top: 0;
            left: 16px;
        }

        .bottomleft {
            position: absolute;
            bottom: 0;
            left: 16px;
        }

        .middle {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }

        hr {
            margin: auto;
            width: 40%;
        }
    </style>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.querySelector(".bgimg").style.backgroundImage = "url('<?php echo e(asset('istockphoto-1412765628-612x612.jpg')); ?>')";
        });
    </script>
</head>
<body>

<div class="bgimg">
    <div class="topleft">
        <!-- <p>Logo</p> -->
    </div>
    <div class="middle">
        <h1>COMING SOON</h1>
        <hr>
    </div>
    <div class="bottomleft">
        <!-- <p>Some text</p> -->
    </div>
</div>

</body>
</html>
<?php /**PATH D:\PROJECTS\carr\resources\views\upcomming.blade.php ENDPATH**/ ?>