<?php
// Test if PHP server is working
echo "Server is working correctly!<br>";

// Output PHP configuration information
phpinfo();
?>
